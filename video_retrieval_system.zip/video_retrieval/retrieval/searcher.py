"""
retrieval/searcher.py
---------------------
Provides the two query modes required by the assignment:
  1. ``search_by_image``  — image-to-video retrieval
  2. ``search_by_video``  — video-to-video retrieval

Both return a ranked list of ``RetrievalResult`` objects so the caller
decides how to present the results (CLI, REST API, Streamlit, etc.).

Design notes
~~~~~~~~~~~~
- ``VideoSearcher`` depends on abstractions (``CLIPEmbedder``,
  ``VideoProcessor``, ``IndexManager``), not concrete implementations,
  following the Dependency Inversion Principle.
- Both search methods follow the same pattern:
    raw input → PIL Image(s) → CLIP embedding → FAISS search → results
  This consistency makes the code easy to extend (e.g. text-to-video query).
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image

from core.embedder import CLIPEmbedder
from core.index_manager import IndexManager, RetrievalResult
from core.video_processor import VideoProcessor
from utils.file_utils import validate_file
from utils.logger import get_logger

logger = get_logger(__name__)


class VideoSearcher:
    """
    Query the video database with an image or a video clip.

    Parameters
    ----------
    embedder : CLIPEmbedder
        Shared CLIP embedding service.
    video_processor : VideoProcessor
        Shared frame extraction service.
    index_manager : IndexManager
        Populated (built or loaded) FAISS index.
    """

    def __init__(
        self,
        embedder: CLIPEmbedder,
        video_processor: VideoProcessor,
        index_manager: IndexManager,
    ) -> None:
        self._embedder = embedder
        self._video_processor = video_processor
        self._index_manager = index_manager

    # ──────────────────────────────────────────────────────────
    # Query: Image → Video
    # ──────────────────────────────────────────────────────────

    def search_by_image(
        self,
        image_path: Path | str,
        top_k: int | None = None,
    ) -> list[RetrievalResult]:
        """
        Find the best matching video(s) for a single query image.

        Pipeline:
          image file → PIL Image → CLIP embedding → FAISS search

        Parameters
        ----------
        image_path : Path | str
            Path to the query image (any format supported by PIL).
        top_k : int | None
            Number of results to return. ``None`` uses the index default.

        Returns
        -------
        list[RetrievalResult]
            Ranked retrieval results (best first).

        Raises
        ------
        FileNotFoundError
            If *image_path* does not exist.
        """
        path = validate_file(image_path, label="Query image")
        logger.info("Image query: %s", path.name)

        image = Image.open(path).convert("RGB")
        query_vector = self._embedder.encode_images([image])  # shape (1, D)

        results = self._index_manager.search(query_vector, top_k=top_k)
        self._log_results(results)
        return results

    # ──────────────────────────────────────────────────────────
    # Query: Video → Video
    # ──────────────────────────────────────────────────────────

    def search_by_video(
        self,
        video_path: Path | str,
        top_k: int | None = None,
    ) -> list[RetrievalResult]:
        """
        Find the best matching video(s) for a query video clip.

        Pipeline:
          video file → sampled frames → mean-pooled CLIP embedding → FAISS search

        Parameters
        ----------
        video_path : Path | str
            Path to the query video clip.
        top_k : int | None
            Number of results to return. ``None`` uses the index default.

        Returns
        -------
        list[RetrievalResult]
            Ranked retrieval results (best first).

        Raises
        ------
        FileNotFoundError
            If *video_path* does not exist.
        RuntimeError
            If no frames can be extracted from the query video.
        """
        path = validate_file(video_path, label="Query video")
        logger.info("Video query: %s", path.name)

        frames = self._video_processor.extract_frames(path)
        if not frames:
            raise RuntimeError(f"Could not extract any frames from: {path}")

        query_vector = self._embedder.aggregate_video_embedding(frames)  # shape (1, D)

        results = self._index_manager.search(query_vector, top_k=top_k)
        self._log_results(results)
        return results

    # ──────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────

    @staticmethod
    def _log_results(results: list[RetrievalResult]) -> None:
        if not results:
            logger.warning("No results returned.")
            return
        for r in results:
            logger.info("  %s", r)
