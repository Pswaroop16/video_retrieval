"""
retrieval/indexer.py
--------------------
Orchestrates the database ingestion pipeline:
  1. Scan the video database directory for supported video files.
  2. Extract frames from each video via ``VideoProcessor``.
  3. Encode frames into a mean-pooled embedding via ``CLIPEmbedder``.
  4. Load all vectors into ``IndexManager`` and optionally persist to disk.

Keeping this orchestration separate from the core classes means:
- Core classes stay single-responsibility and unit-testable.
- You can swap the indexing strategy (e.g. batch processing, async) without
  touching the model or FAISS code.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
from tqdm import tqdm

from config.settings import VIDEO_DB_DIR, INDEX_SAVE_PATH, PATHS_SAVE_PATH
from core.video_processor import VideoProcessor
from core.embedder import CLIPEmbedder
from core.index_manager import IndexManager
from utils.file_utils import iter_video_files
from utils.logger import get_logger

logger = get_logger(__name__)


class DatabaseIndexer:
    """
    Build (or rebuild) the FAISS index from a directory of video files.

    Parameters
    ----------
    video_processor : VideoProcessor
        Frame extraction service.
    embedder : CLIPEmbedder
        CLIP embedding service.
    index_manager : IndexManager
        FAISS index wrapper.
    """

    def __init__(
        self,
        video_processor: VideoProcessor,
        embedder: CLIPEmbedder,
        index_manager: IndexManager,
    ) -> None:
        self._video_processor = video_processor
        self._embedder = embedder
        self._index_manager = index_manager

    # ──────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────

    def build_index(
        self,
        db_dir: Path = VIDEO_DB_DIR,
        save: bool = True,
        index_path: Path = INDEX_SAVE_PATH,
        paths_path: Path = PATHS_SAVE_PATH,
    ) -> None:
        """
        Scan *db_dir*, encode all videos, and populate the index.

        Parameters
        ----------
        db_dir : Path
            Directory containing the video database.
        save : bool
            Whether to persist the index to disk after building.
        index_path : Path
            Destination for the serialised FAISS index.
        paths_path : Path
            Destination for the video-path array.

        Raises
        ------
        RuntimeError
            If no valid video files are found in *db_dir*.
        """
        logger.info("Starting database indexing from: %s", db_dir)
        video_files = list(iter_video_files(db_dir))

        if not video_files:
            raise RuntimeError(f"No supported video files found in: {db_dir}")

        embeddings: list[np.ndarray] = []
        paths: list[Path] = []

        for video_path in tqdm(video_files, desc="Indexing videos", unit="video"):
            try:
                frames = self._video_processor.extract_frames(video_path)
                if not frames:
                    logger.warning("Skipping %s: no frames extracted.", video_path.name)
                    continue

                vector = self._embedder.aggregate_video_embedding(frames)
                embeddings.append(vector)
                paths.append(video_path)

            except Exception as exc:
                logger.error("Failed to process %s: %s", video_path.name, exc)
                continue

        if not embeddings:
            raise RuntimeError("No videos were successfully encoded.")

        all_embeddings = np.vstack(embeddings).astype("float32")
        self._index_manager.build(all_embeddings, paths)

        if save:
            self._index_manager.save(index_path, paths_path)

        logger.info(
            "Indexing complete. %d/%d videos indexed.",
            len(paths), len(video_files),
        )
