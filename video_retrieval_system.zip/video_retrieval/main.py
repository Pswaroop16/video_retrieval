"""
main.py
-------
CLI entry point for the Video Retrieval System.

Usage examples
--------------
# Build index then query with an image
python main.py --query-type image --query-file sunset.jpg

# Query with a video (reuse previously saved index)
python main.py --query-type video --query-file clip.mp4 --load-index

# Build index only (no query)
python main.py --build-only

# Return top-3 results
python main.py --query-type image --query-file frame.png --top-k 3

Architecture note
-----------------
``main.py`` is intentionally thin: it only wires dependencies together and
delegates all logic to the service layer.  No business logic lives here.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from config.settings import (
    QUERY_IMAGE_DIR,
    QUERY_VIDEO_DIR,
    INDEX_SAVE_PATH,
    PATHS_SAVE_PATH,
    TOP_K,
)
from core.video_processor import VideoProcessor
from core.embedder import CLIPEmbedder
from core.index_manager import IndexManager
from retrieval.indexer import DatabaseIndexer
from retrieval.searcher import VideoSearcher
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────── Dependency wiring ───────────────────────────────────

def build_services() -> tuple[VideoProcessor, CLIPEmbedder, IndexManager]:
    """Instantiate and return the three core services."""
    video_processor = VideoProcessor()
    embedder = CLIPEmbedder()
    index_manager = IndexManager()
    return video_processor, embedder, index_manager


# ─────────────────────── Argument parsing ────────────────────────────────────

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Multimodal Video Retrieval System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # ── Index management ─────────────────────────────────────
    index_group = parser.add_mutually_exclusive_group()
    index_group.add_argument(
        "--build-only",
        action="store_true",
        help="Build and save the index without running a query.",
    )
    index_group.add_argument(
        "--load-index",
        action="store_true",
        help="Load a pre-built index from disk instead of rebuilding.",
    )

    # ── Query ────────────────────────────────────────────────
    parser.add_argument(
        "--query-type",
        choices=["image", "video"],
        help="Type of query: 'image' or 'video'.",
    )
    parser.add_argument(
        "--query-file",
        type=str,
        help="Query file name (looked up inside the appropriate query folder).",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=TOP_K,
        help=f"Number of results to return (default: {TOP_K}).",
    )

    return parser.parse_args(argv)


# ─────────────────────── Interactive mode ────────────────────────────────────

def interactive_mode(searcher: VideoSearcher, top_k: int) -> None:
    """Fall back to the original interactive CLI when no args are provided."""
    print("\n┌─────────────────────────────────────┐")
    print("│   Multimodal Video Retrieval System │")
    print("└─────────────────────────────────────┘")
    print("\nChoose Query Type:")
    print("  1 - Image query")
    print("  2 - Video query")

    choice = input("\nEnter choice [1/2]: ").strip()

    if choice == "1":
        name = input("Enter image file name: ").strip()
        path = QUERY_IMAGE_DIR / name
        if not path.exists():
            print(f"\n[ERROR] Image not found in {QUERY_IMAGE_DIR}: {name}")
            sys.exit(1)
        results = searcher.search_by_image(path, top_k=top_k)

    elif choice == "2":
        name = input("Enter video file name: ").strip()
        path = QUERY_VIDEO_DIR / name
        if not path.exists():
            print(f"\n[ERROR] Video not found in {QUERY_VIDEO_DIR}: {name}")
            sys.exit(1)
        results = searcher.search_by_video(path, top_k=top_k)

    else:
        print("[ERROR] Invalid choice.")
        sys.exit(1)

    _print_results(results)


# ─────────────────────── Result display ──────────────────────────────────────

def _print_results(results) -> None:
    if not results:
        print("\nNo results found.")
        return
    print(f"\n{'─'*45}")
    print(f"  Top {len(results)} Result(s)")
    print(f"{'─'*45}")
    for r in results:
        print(f"  {r}")
    print(f"{'─'*45}\n")


# ─────────────────────── Main ────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)

    video_processor, embedder, index_manager = build_services()
    indexer = DatabaseIndexer(video_processor, embedder, index_manager)
    searcher = VideoSearcher(embedder, video_processor, index_manager)

    # ── Step 1: Build or load the index ──────────────────────
    if args.load_index:
        logger.info("Loading pre-built index from disk …")
        index_manager.load(INDEX_SAVE_PATH, PATHS_SAVE_PATH)
    else:
        indexer.build_index(save=True)

    # ── Step 2: Handle build-only mode ───────────────────────
    if args.build_only:
        logger.info("Index built and saved. Exiting (--build-only).")
        return

    # ── Step 3: Run query ────────────────────────────────────
    if args.query_type is None:
        # No CLI args supplied → fall back to interactive mode
        interactive_mode(searcher, top_k=args.top_k)
        return

    if args.query_file is None:
        logger.error("--query-file is required when --query-type is specified.")
        sys.exit(1)

    if args.query_type == "image":
        path = QUERY_IMAGE_DIR / args.query_file
        results = searcher.search_by_image(path, top_k=args.top_k)
    else:
        path = QUERY_VIDEO_DIR / args.query_file
        results = searcher.search_by_video(path, top_k=args.top_k)

    _print_results(results)


if __name__ == "__main__":
    main()
