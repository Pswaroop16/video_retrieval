"""
core/embedder.py
----------------
Wraps OpenCLIP to produce L2-normalised image embeddings.

Design notes
~~~~~~~~~~~~
- ``CLIPEmbedder`` loads the model **once** at construction time.
  All callers share the same instance (pass it via dependency injection
  rather than re-constructing inside functions).
- ``encode_images`` accepts any list of PIL Images, keeping it agnostic
  to whether they came from a video, a single query image, or any other source.
- Batching is handled internally so callers don't need to think about GPU memory.
"""

from __future__ import annotations

import torch
import open_clip
import numpy as np
from PIL import Image

from config.settings import CLIP_MODEL_NAME, CLIP_PRETRAINED, DEVICE
from utils.logger import get_logger

logger = get_logger(__name__)


class CLIPEmbedder:
    """
    Generate L2-normalised CLIP embeddings from PIL Images.

    Parameters
    ----------
    model_name : str
        OpenCLIP model architecture (default: ``CLIP_MODEL_NAME``).
    pretrained : str
        Pretrained weights identifier (default: ``CLIP_PRETRAINED``).
    device : str
        Torch device string — ``"cuda"`` or ``"cpu"`` (default: ``DEVICE``).
    batch_size : int
        Number of images processed per forward pass.
        Reduce if you hit GPU OOM errors.
    """

    def __init__(
        self,
        model_name: str = CLIP_MODEL_NAME,
        pretrained: str = CLIP_PRETRAINED,
        device: str = DEVICE,
        batch_size: int = 64,
    ) -> None:
        self.device = device
        self.batch_size = batch_size

        logger.info(
            "Loading CLIP model '%s' (pretrained='%s') on device='%s' …",
            model_name, pretrained, device,
        )
        self._model, _, self._preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained
        )
        self._model = self._model.to(device)
        self._model.eval()
        logger.info("CLIP model loaded successfully.")

    # ──────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────

    def encode_images(self, images: list[Image.Image]) -> np.ndarray:
        """
        Encode a list of PIL Images into a normalised float32 embedding matrix.

        Parameters
        ----------
        images : list[Image.Image]
            Input images (RGB mode recommended).

        Returns
        -------
        np.ndarray
            Shape ``(N, embedding_dim)``, dtype ``float32``.
            Each row is an L2-normalised feature vector.

        Raises
        ------
        ValueError
            If *images* is empty.
        """
        if not images:
            raise ValueError("encode_images received an empty image list.")

        all_features: list[np.ndarray] = []

        # Process in mini-batches to respect GPU memory limits
        for start in range(0, len(images), self.batch_size):
            batch = images[start : start + self.batch_size]
            tensors = torch.stack(
                [self._preprocess(img) for img in batch]
            ).to(self.device)

            with torch.no_grad():
                features = self._model.encode_image(tensors)

            # L2 normalise → cosine similarity becomes inner product
            features = features / features.norm(dim=-1, keepdim=True)
            all_features.append(features.cpu().numpy())

        return np.concatenate(all_features, axis=0).astype("float32")

    def aggregate_video_embedding(self, images: list[Image.Image]) -> np.ndarray:
        """
        Produce a single embedding vector for a video by mean-pooling its frame embeddings.

        Parameters
        ----------
        images : list[Image.Image]
            Frames sampled from the video.

        Returns
        -------
        np.ndarray
            Shape ``(1, embedding_dim)``, dtype ``float32``.
        """
        frame_features = self.encode_images(images)
        video_vector = np.mean(frame_features, axis=0, keepdims=True).astype("float32")
        # Re-normalise the pooled vector
        norm = np.linalg.norm(video_vector, axis=-1, keepdims=True)
        video_vector = video_vector / np.clip(norm, a_min=1e-8, a_max=None)
        return video_vector
