"""
core/video_processor.py
-----------------------
Responsible for one thing only: turning a video file into a list of PIL Images.

Design notes
~~~~~~~~~~~~
- ``VideoProcessor`` is a stateless service class — instantiate once, call many times.
- Frame sampling uses ``np.linspace`` so it works correctly on any clip length,
  including the 2–3-second short clips required by this project.
- All OpenCV resource management is handled with try/finally to prevent
  file-descriptor leaks even on error.
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from config.settings import FRAME_SAMPLES
from utils.logger import get_logger
from utils.file_utils import validate_file

logger = get_logger(__name__)


class VideoProcessor:
    """
    Extract uniformly-sampled frames from a video file.

    Parameters
    ----------
    num_samples : int
        Number of frames to sample per video (default: ``FRAME_SAMPLES``).
    """

    def __init__(self, num_samples: int = FRAME_SAMPLES) -> None:
        self.num_samples = num_samples
        logger.debug("VideoProcessor initialised with num_samples=%d", num_samples)

    # ──────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────

    def extract_frames(self, video_path: Path | str) -> list[Image.Image]:
        """
        Sample ``self.num_samples`` frames evenly across the video.

        Parameters
        ----------
        video_path : Path | str
            Path to the video file.

        Returns
        -------
        list[Image.Image]
            Extracted frames as RGB PIL Images.
            Returns an empty list if the video cannot be opened or has no frames.

        Raises
        ------
        FileNotFoundError
            If *video_path* does not exist.
        """
        path = validate_file(video_path, label="Video file")
        logger.debug("Extracting frames from: %s", path.name)

        cap = cv2.VideoCapture(str(path))
        frames: list[Image.Image] = []

        try:
            if not cap.isOpened():
                logger.error("OpenCV could not open video: %s", path)
                return frames

            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            if total_frames <= 0:
                logger.warning("Video reports 0 frames: %s", path.name)
                return frames

            # Clamp sample count to available frames
            actual_samples = min(self.num_samples, total_frames)
            frame_indices = np.linspace(0, total_frames - 1, actual_samples, dtype=int)

            for idx in frame_indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
                success, frame = cap.read()
                if not success:
                    logger.warning("Failed to read frame %d from %s", idx, path.name)
                    continue
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frames.append(Image.fromarray(rgb_frame))

        finally:
            cap.release()

        logger.debug("Extracted %d frames from %s", len(frames), path.name)
        return frames
