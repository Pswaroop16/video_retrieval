"""
core/index_manager.py
---------------------
Owns the FAISS index lifecycle: building, persisting, loading, and searching.

Design notes
~~~~~~~~~~~~
- ``IndexManager`` is stateful: it holds the FAISS index and the ordered
  list of video paths that correspond to index rows.
- ``IndexFlatIP`` (inner product) is used because embeddings are already
  L2-normalised, making inner product equivalent to cosine similarity —
  the right metric for CLIP features.
- Persistence (save / load) lets you build the index once and reuse it
  across runs without re-encoding the entire database.
- ``search`` is kept generic: it accepts any (1, D) query vector and
  returns ranked results, supporting future top-k expansion.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import faiss
import numpy as np

from config.settings import EMBEDDING_DIM, TOP_K, INDEX_SAVE_PATH, PATHS_SAVE_PATH
from utils.logger import get_logger

logger = get_logger(__name__)


# ─────────────────────────── Result DTO ──────────────────────────────────────

@dataclass(frozen=True)
class RetrievalResult:
    """
    Immutable data-transfer object for a single retrieval hit.

    Attributes
    ----------
    rank : int
        1-based rank (1 = best match).
    video_path : Path
        Absolute path to the matched video file.
    score : float
        Cosine similarity score in the range [-1, 1].
    """
    rank: int
    video_path: Path
    score: float

    def __str__(self) -> str:
        return f"[Rank {self.rank}] {self.video_path.name}  (score={self.score:.4f})"


# ─────────────────────────── Manager ─────────────────────────────────────────

class IndexManager:
    """
    Build, persist, load, and query the FAISS index.

    Parameters
    ----------
    embedding_dim : int
        Dimensionality of embedding vectors (default: ``EMBEDDING_DIM``).
    top_k : int
        Default number of nearest neighbours to retrieve (default: ``TOP_K``).
    """

    def __init__(
        self,
        embedding_dim: int = EMBEDDING_DIM,
        top_k: int = TOP_K,
    ) -> None:
        self.embedding_dim = embedding_dim
        self.top_k = top_k
        self._index: faiss.Index | None = None
        self._video_paths: list[Path] = []

    # ──────────────────────────────────────────────────────────
    # Build
    # ──────────────────────────────────────────────────────────

    def build(
        self,
        embeddings: np.ndarray,
        video_paths: list[Path],
    ) -> None:
        """
        Construct a new FAISS IndexFlatIP from pre-computed embeddings.

        Parameters
        ----------
        embeddings : np.ndarray
            Shape ``(N, embedding_dim)``, dtype ``float32``.
            Each row is the mean-pooled, L2-normalised vector for one video.
        video_paths : list[Path]
            Ordered list of video paths; ``video_paths[i]`` corresponds to
            ``embeddings[i]``.

        Raises
        ------
        ValueError
            If *embeddings* and *video_paths* have different lengths, or if
            *embeddings* is empty.
        """
        if len(embeddings) == 0:
            raise ValueError("Cannot build index from zero embeddings.")
        if len(embeddings) != len(video_paths):
            raise ValueError(
                f"Mismatch: {len(embeddings)} embeddings vs "
                f"{len(video_paths)} video paths."
            )

        logger.info("Building FAISS IndexFlatIP for %d videos …", len(embeddings))
        self._index = faiss.IndexFlatIP(self.embedding_dim)
        self._index.add(embeddings)
        self._video_paths = list(video_paths)
        logger.info("Index built with %d entries.", self._index.ntotal)

    # ──────────────────────────────────────────────────────────
    # Persist / Load
    # ──────────────────────────────────────────────────────────

    def save(
        self,
        index_path: Path = INDEX_SAVE_PATH,
        paths_path: Path = PATHS_SAVE_PATH,
    ) -> None:
        """
        Persist the FAISS index and video-path list to disk.

        Parameters
        ----------
        index_path : Path
            Destination for the serialised FAISS index.
        paths_path : Path
            Destination for the ``npy`` video-path array.

        Raises
        ------
        RuntimeError
            If the index has not been built yet.
        """
        self._require_index()
        faiss.write_index(self._index, str(index_path))
        np.save(str(paths_path), np.array([str(p) for p in self._video_paths]))
        logger.info("Index saved to %s", index_path)

    def load(
        self,
        index_path: Path = INDEX_SAVE_PATH,
        paths_path: Path = PATHS_SAVE_PATH,
    ) -> None:
        """
        Restore a previously saved index from disk.

        Parameters
        ----------
        index_path : Path
            Path to a serialised FAISS index file.
        paths_path : Path
            Path to the matching ``.npy`` video-path array.

        Raises
        ------
        FileNotFoundError
            If either file is missing.
        """
        if not index_path.exists():
            raise FileNotFoundError(f"FAISS index not found: {index_path}")
        if not paths_path.exists():
            raise FileNotFoundError(f"Video-paths file not found: {paths_path}")

        self._index = faiss.read_index(str(index_path))
        raw_paths = np.load(str(paths_path), allow_pickle=True)
        self._video_paths = [Path(p) for p in raw_paths]
        logger.info("Index loaded from %s (%d entries).", index_path, self._index.ntotal)

    # ──────────────────────────────────────────────────────────
    # Search
    # ──────────────────────────────────────────────────────────

    def search(
        self,
        query_vector: np.ndarray,
        top_k: int | None = None,
    ) -> list[RetrievalResult]:
        """
        Find the *top_k* closest videos to *query_vector*.

        Parameters
        ----------
        query_vector : np.ndarray
            Shape ``(1, embedding_dim)``, dtype ``float32``.
        top_k : int | None
            Override the default ``self.top_k`` for this query.

        Returns
        -------
        list[RetrievalResult]
            Ranked list of results (best first).

        Raises
        ------
        RuntimeError
            If the index has not been built or loaded.
        ValueError
            If *query_vector* has the wrong shape.
        """
        self._require_index()

        k = top_k if top_k is not None else self.top_k
        k = min(k, len(self._video_paths))  # can't return more than we have

        if query_vector.ndim != 2 or query_vector.shape[0] != 1:
            raise ValueError(
                f"query_vector must have shape (1, D), got {query_vector.shape}"
            )

        scores, indices = self._index.search(query_vector, k)

        results: list[RetrievalResult] = []
        for rank, (idx, score) in enumerate(
            zip(indices[0], scores[0]), start=1
        ):
            if idx < 0:
                continue  # FAISS returns -1 when fewer results than k exist
            results.append(
                RetrievalResult(
                    rank=rank,
                    video_path=self._video_paths[idx],
                    score=float(score),
                )
            )
        return results

    # ──────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────

    @property
    def is_built(self) -> bool:
        """``True`` if the index has been built or loaded."""
        return self._index is not None and self._index.ntotal > 0

    def _require_index(self) -> None:
        if not self.is_built:
            raise RuntimeError(
                "Index is not ready. Call build() or load() first."
            )
