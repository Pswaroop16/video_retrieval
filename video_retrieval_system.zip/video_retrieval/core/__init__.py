"""Core domain logic package."""
from .video_processor import VideoProcessor
from .embedder import CLIPEmbedder
from .index_manager import IndexManager, RetrievalResult

__all__ = [
    "VideoProcessor",
    "CLIPEmbedder",
    "IndexManager",
    "RetrievalResult",
]
