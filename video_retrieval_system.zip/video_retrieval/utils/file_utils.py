"""
utils/file_utils.py
-------------------
Reusable helpers for file-system operations:
  - validating file / directory existence
  - listing video files in a directory
  - basic path sanity checks

Keeping I/O helpers here prevents ad-hoc ``os.path`` calls
from scattering throughout the codebase.
"""

from pathlib import Path
from typing import Generator

from config.settings import SUPPORTED_VIDEO_EXTS
from utils.logger import get_logger

logger = get_logger(__name__)


def validate_file(path: Path | str, label: str = "File") -> Path:
    """
    Assert that *path* points to an existing regular file.

    Parameters
    ----------
    path : Path | str
        File path to check.
    label : str
        Human-readable name used in the error message.

    Returns
    -------
    Path
        Resolved ``Path`` object.

    Raises
    ------
    FileNotFoundError
        If the path does not exist or is not a file.
    """
    p = Path(path).resolve()
    if not p.is_file():
        raise FileNotFoundError(f"{label} not found: {p}")
    return p


def validate_directory(path: Path | str, label: str = "Directory") -> Path:
    """
    Assert that *path* points to an existing directory.

    Parameters
    ----------
    path : Path | str
        Directory path to check.
    label : str
        Human-readable name used in the error message.

    Returns
    -------
    Path
        Resolved ``Path`` object.

    Raises
    ------
    NotADirectoryError
        If the path does not exist or is not a directory.
    """
    p = Path(path).resolve()
    if not p.is_dir():
        raise NotADirectoryError(f"{label} not found: {p}")
    return p


def iter_video_files(directory: Path | str) -> Generator[Path, None, None]:
    """
    Yield all video files found directly inside *directory*.

    Only files whose suffix matches ``SUPPORTED_VIDEO_EXTS`` (case-insensitive)
    are yielded.  Sub-directories are not recursed.

    Parameters
    ----------
    directory : Path | str
        Folder to scan.

    Yields
    ------
    Path
        Absolute path of each video file found.

    Raises
    ------
    NotADirectoryError
        If *directory* is not a valid directory.
    """
    dir_path = validate_directory(directory, label="Video database directory")
    found = 0
    for entry in sorted(dir_path.iterdir()):
        if entry.is_file() and entry.suffix.lower() in SUPPORTED_VIDEO_EXTS:
            found += 1
            yield entry
    if found == 0:
        logger.warning("No supported video files found in %s", dir_path)
