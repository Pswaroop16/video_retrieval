# 🎬 Multimodal Video Retrieval System

A production-ready, modular system for retrieving the best-matching video from a database using either an **image query** or a **video query**, powered by [OpenCLIP](https://github.com/mlfoundations/open_clip) embeddings and [FAISS](https://github.com/facebookresearch/faiss) similarity search.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Folder Structure](#2-folder-structure)
3. [File-by-File Explanation](#3-file-by-file-explanation)
4. [How Files Connect Together](#4-how-files-connect-together)
5. [Architecture Principles](#5-architecture-principles)
6. [Core vs Utility Files](#6-core-vs-utility-files)
7. [Quick Start](#7-quick-start)
8. [Usage](#8-usage)
9. [End-to-End Pipeline](#9-end-to-end-pipeline)
10. [Time Complexity Analysis](#10-time-complexity-analysis)
11. [Memory Optimisation](#11-memory-optimisation)
12. [Why This Design Beats a Single File](#12-why-this-design-beats-a-single-file)
13. [Future Improvements](#13-future-improvements)

---

## 1. Project Overview

| Feature | Detail |
|---|---|
| Query types | Image → Video, Video → Video |
| Embedding model | OpenCLIP `ViT-B-32` (OpenAI weights) |
| Similarity index | FAISS `IndexFlatIP` (cosine similarity) |
| Persistence | Index + path list saved to `artifacts/` |
| Python version | 3.10+ |
| Device support | CPU and CUDA |

---

## 2. Folder Structure

```
video_retrieval/
│
├── main.py                       ← CLI entry point
│
├── config/
│   ├── __init__.py
│   └── settings.py               ← ALL constants & paths (single source of truth)
│
├── core/                         ← Pure domain logic, no I/O side-effects
│   ├── __init__.py
│   ├── video_processor.py        ← Frame extraction (VideoProcessor)
│   ├── embedder.py               ← CLIP embedding generation (CLIPEmbedder)
│   └── index_manager.py          ← FAISS index lifecycle (IndexManager, RetrievalResult)
│
├── retrieval/                    ← Orchestration layer
│   ├── __init__.py
│   ├── indexer.py                ← Database ingestion pipeline (DatabaseIndexer)
│   └── searcher.py               ← Query interface (VideoSearcher)
│
├── utils/
│   ├── __init__.py
│   ├── logger.py                 ← Centralised logging factory
│   └── file_utils.py             ← File/directory validation helpers
│
├── tests/
│   ├── __init__.py
│   └── test_core.py              ← Unit tests (mock-based, no GPU required)
│
├── database/                     ← Put your .mp4/.avi/.mov clips here
├── query_images/                 ← Put query images here
├── query_videos/                 ← Put query video clips here
├── artifacts/                    ← Auto-generated: faiss.index, video_paths.npy
├── logs/                         ← Auto-generated: retrieval.log
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 3. File-by-File Explanation

### `config/settings.py` — Configuration hub
Single source of truth for every constant: directory paths, model names,
device selection, frame sampling count, top-k, logging settings.
**Change behaviour here — never hard-code values elsewhere.**

### `core/video_processor.py` — Frame extractor
`VideoProcessor.extract_frames(video_path)` opens a video with OpenCV,
uniformly samples `FRAME_SAMPLES` frames using `np.linspace`, converts each
to RGB PIL Image, and returns the list.  Resource-safe: `cap.release()` is
guaranteed via `try/finally`.

### `core/embedder.py` — CLIP embedding service
`CLIPEmbedder` loads the OpenCLIP model once at construction.
- `encode_images(images)` → `(N, 512)` float32 array of L2-normalised vectors.
- `aggregate_video_embedding(images)` → `(1, 512)` mean-pooled + re-normalised vector representing one video.

Batching is handled internally; callers don't manage GPU memory.

### `core/index_manager.py` — FAISS wrapper
`IndexManager` owns the full lifecycle of the FAISS index:
- `build(embeddings, paths)` — creates `IndexFlatIP` and loads all vectors.
- `save()` / `load()` — persist and restore to/from `artifacts/`.
- `search(query_vector, top_k)` — returns a ranked `list[RetrievalResult]`.

`RetrievalResult` is a frozen dataclass: `rank`, `video_path`, `score`.

### `retrieval/indexer.py` — Database ingestion pipeline
`DatabaseIndexer.build_index()` orchestrates:
1. Scan the database directory (`iter_video_files`).
2. For each video: extract frames → encode → aggregate.
3. Stack all vectors → build FAISS index → optionally save.

Skips corrupt files gracefully with a warning; raises `RuntimeError` only if
*no* videos succeed.

### `retrieval/searcher.py` — Query interface
`VideoSearcher` exposes two public methods:
- `search_by_image(path, top_k)` — image → CLIP embedding → FAISS search.
- `search_by_video(path, top_k)` — frames → mean embedding → FAISS search.

Both return `list[RetrievalResult]`.

### `utils/logger.py` — Logging factory
`get_logger(name)` returns a pre-configured logger that writes to both
stdout (with colour) and a rotating file under `logs/`.

### `utils/file_utils.py` — File helpers
`validate_file`, `validate_directory`, `iter_video_files` — reusable I/O
guards that raise clear exceptions rather than cryptic OS errors.

### `main.py` — CLI entry point
Parses arguments, wires dependencies, calls services.
Zero business logic. Supports both flag-driven and interactive modes.

### `tests/test_core.py` — Unit tests
Mock-based tests covering `VideoProcessor`, `CLIPEmbedder`, and
`IndexManager`.  No real videos or GPU needed; runs in seconds.

---

## 4. How Files Connect Together

```
main.py
  │
  ├─ instantiates ──► VideoProcessor  (core/video_processor.py)
  ├─ instantiates ──► CLIPEmbedder    (core/embedder.py)
  ├─ instantiates ──► IndexManager    (core/index_manager.py)
  │
  ├─ passes into ───► DatabaseIndexer (retrieval/indexer.py)
  │                     uses: VideoProcessor, CLIPEmbedder, IndexManager
  │                     uses: iter_video_files (utils/file_utils.py)
  │
  └─ passes into ───► VideoSearcher   (retrieval/searcher.py)
                        uses: CLIPEmbedder, VideoProcessor, IndexManager
```

All modules import constants from `config/settings.py` and loggers from
`utils/logger.py`.  Dependency flow is **always top-down**: `retrieval` →
`core` → `config`/`utils`.  Nothing in `core` imports from `retrieval`.

---

## 5. Architecture Principles

### Single Responsibility (S)
Each class does exactly one thing:
`VideoProcessor` extracts frames. `CLIPEmbedder` encodes. `IndexManager` searches.

### Open/Closed (O)
Add a new query type (e.g. text-to-video) by adding a method to
`VideoSearcher` without touching `CLIPEmbedder` or `IndexManager`.

### Liskov Substitution (L)
`CLIPEmbedder` could be swapped for a `TimeSformerEmbedder` as long as it
exposes the same `encode_images` / `aggregate_video_embedding` interface.

### Interface Segregation (I)
`VideoSearcher` only depends on the parts of `CLIPEmbedder` it needs
(`encode_images`, `aggregate_video_embedding`), not on model-loading internals.

### Dependency Inversion (D)
`DatabaseIndexer` and `VideoSearcher` accept their dependencies via the
constructor; the caller (`main.py`) wires everything together.  No `import`
inside methods.

---

## 6. Core vs Utility Files

### Core files (business logic)
| File | Role |
|---|---|
| `core/video_processor.py` | Frame extraction — the "sensor" |
| `core/embedder.py` | Embedding generation — the "brain" |
| `core/index_manager.py` | Similarity search — the "memory" |
| `retrieval/indexer.py` | Ingestion pipeline orchestrator |
| `retrieval/searcher.py` | Query pipeline orchestrator |

### Utility / helper files (infrastructure)
| File | Role |
|---|---|
| `config/settings.py` | All constants — tune without code changes |
| `utils/logger.py` | Consistent logging across all modules |
| `utils/file_utils.py` | I/O guards — prevents silent failures |
| `main.py` | Dependency wiring and CLI — no logic |

---

## 7. Quick Start

```bash
# 1. Clone / copy the project
cd video_retrieval

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Add videos to the database
cp /your/clips/*.mp4 database/

# 5. Add query files
cp query_frame.jpg query_images/
cp query_clip.mp4  query_videos/

# 6. Run (interactive)
python main.py

# 7. Or run with flags
python main.py --query-type image --query-file query_frame.jpg
python main.py --query-type video --query-file query_clip.mp4 --top-k 3

# 8. Build index once, reuse later
python main.py --build-only
python main.py --load-index --query-type image --query-file query_frame.jpg
```

---

## 8. Usage

### Interactive mode
```
python main.py

┌─────────────────────────────────────┐
│   Multimodal Video Retrieval System │
└─────────────────────────────────────┘

Choose Query Type:
  1 - Image query
  2 - Video query

Enter choice [1/2]: 1
Enter image file name: sunset.jpg

─────────────────────────────────────────────
  Top 1 Result(s)
─────────────────────────────────────────────
  [Rank 1] beach_sunset_clip.mp4  (score=0.9231)
─────────────────────────────────────────────
```

### CLI flags
```bash
# Image query, top-3 results
python main.py --query-type image --query-file frame.jpg --top-k 3

# Video query, reuse saved index
python main.py --load-index --query-type video --query-file clip.mp4
```

### Run tests
```bash
python -m pytest tests/ -v
```

---

## 9. End-to-End Pipeline

### Indexing pipeline (run once)

```
database/
  video_1.mp4 ──► VideoProcessor.extract_frames()
                   15 uniformly-sampled PIL Images
                    │
                    ▼
               CLIPEmbedder.aggregate_video_embedding()
                   encode_images() → (15, 512) matrix
                   np.mean(axis=0)  → (1, 512) vector
                   L2 re-normalise  → unit vector
                    │
  video_2.mp4 ──► ... (same pipeline)
  video_N.mp4 ──► ...
                    │
                    ▼
               IndexManager.build(embeddings, paths)
                   faiss.IndexFlatIP  ← all N vectors
                    │
                    ▼
               IndexManager.save()
                   artifacts/faiss.index
                   artifacts/video_paths.npy
```

### Query pipeline (image)

```
query_images/frame.jpg
  │
  ▼
PIL.Image.open() → RGB Image
  │
  ▼
CLIPEmbedder.encode_images([image])
  → (1, 512) L2-normalised float32 vector
  │
  ▼
IndexManager.search(query_vector, top_k=1)
  faiss.IndexFlatIP.search()
  inner product ≡ cosine similarity (since vectors are unit-normalised)
  │
  ▼
list[RetrievalResult]
  [Rank 1] matched_video.mp4  (score=0.9231)
```

### Query pipeline (video)

```
query_videos/clip.mp4
  │
  ▼
VideoProcessor.extract_frames()
  15 uniformly-sampled PIL Images
  │
  ▼
CLIPEmbedder.aggregate_video_embedding()
  (15, 512) → mean-pool → L2 normalise → (1, 512)
  │
  ▼
IndexManager.search(query_vector, top_k=1)
  │
  ▼
list[RetrievalResult]
```

---

## 10. Time Complexity Analysis

### Indexing

| Step | Complexity | Notes |
|---|---|---|
| Frame extraction | O(N · S) | N videos, S sampled frames each |
| CLIP encoding (per video) | O(S · D²) | ViT forward pass; D = model dim |
| Mean pooling | O(S · D) | Trivial |
| FAISS build | O(N · D) | `IndexFlatIP.add` is linear |
| **Total indexing** | **O(N · S · D²)** | Dominated by CLIP inference |

### Search (single query)

| Step | Complexity | Notes |
|---|---|---|
| Query encoding | O(S · D²) | ViT forward pass |
| FAISS flat search | O(N · D) | Exact nearest-neighbour scan |
| **Total search** | **O(N · D)** | After encoding |

For N=10,000 videos and D=512: flat FAISS search ≈ 5 million FLOPs — sub-millisecond on CPU.  Switch to `IndexIVFFlat` for approximate search at N > 100,000.

---

## 11. Memory Optimisation

| Technique | How to apply |
|---|---|
| **Reduce FRAME_SAMPLES** | Lower `FRAME_SAMPLES` in `settings.py` (e.g. 5 instead of 15) — 3× memory/time reduction during indexing. |
| **Half-precision embeddings** | Store index with `float16`; cast to `float32` only for FAISS calls. Halves index RAM. |
| **FAISS IVF index** | Replace `IndexFlatIP` with `IndexIVFFlat` for approximate search on large databases (>100K videos). |
| **Streaming frame extraction** | `VideoProcessor.extract_frames` already yields frames lazily; extend `encode_images` to accept a generator and process one batch at a time. |
| **Persistent cache** | Save per-video embedding vectors to disk alongside the index so re-indexing skips already-processed files. |
| **Batch size tuning** | Reduce `CLIPEmbedder(batch_size=...)` if you hit GPU OOM on large frame counts. |

---

## 12. Why This Design Beats a Single File

| Concern | Single file | This architecture |
|---|---|---|
| **Testing** | Must mock entire script | Each class tested in isolation |
| **Reuse** | Copy-paste functions | Import any service independently |
| **Debugging** | Search 200-line file | Jump directly to the failing module |
| **Extension** | Edit in-place, risk breaking everything | Add a new file; existing code untouched |
| **Team work** | Merge conflicts everywhere | Modules owned independently |
| **Config changes** | Hunt for hard-coded strings | Edit one line in `settings.py` |
| **API / UI layer** | Rewrite from scratch | Import `VideoSearcher`, wrap in FastAPI |
| **Logging** | `print()` statements | Structured, levelled, file-backed logs |
| **Error handling** | Generic exceptions | Typed, descriptive exceptions at source |

---

## 13. Future Improvements

### Near-term
- [ ] **Text-to-video retrieval** — add `search_by_text(prompt)` to `VideoSearcher` using `open_clip.tokenize` (CLIP supports text encoding out of the box).
- [ ] **Top-k CLI flag** — already implemented (`--top-k N`).
- [ ] **Incremental indexing** — skip videos already in the index by caching a `{path: hash}` manifest.
- [ ] **Approximate FAISS index** — replace `IndexFlatIP` with `IndexIVFFlat` or `IndexHNSWFlat` for N > 100K.

### Medium-term
- [ ] **REST API** — wrap `VideoSearcher` in a FastAPI app; each query becomes a POST `/search/image` or `/search/video` endpoint.
- [ ] **Streamlit UI** — drag-and-drop image/video → ranked results with thumbnails.
- [ ] **Temporal embeddings** — replace mean-pooling with a lightweight transformer over frame embeddings for better video-to-video accuracy.
- [ ] **Metadata filtering** — attach metadata (tags, duration, source) to each video; pre-filter FAISS results.

### Long-term
- [ ] **Distributed indexing** — shard the FAISS index across multiple nodes using `faiss.IndexShards`.
- [ ] **Model hot-swap** — abstract `CLIPEmbedder` behind an `Embedder` Protocol so you can swap to BLIP-2, InternVideo, or any future model.
- [ ] **Active learning loop** — collect user click-through data to fine-tune the embedding model on your specific video domain.
