"""
settings.py
-----------
Central configuration file for the Video Retrieval System.
All constants, paths, and model settings live here.
Modify this file to tune behaviour without touching core logic.
"""

from pathlib import Path
import torch

# ─────────────────────────── Paths ───────────────────────────
BASE_DIR: Path = Path(__file__).resolve().parent.parent

VIDEO_DB_DIR: Path      = BASE_DIR / "database"
QUERY_IMAGE_DIR: Path   = BASE_DIR / "query_images"
QUERY_VIDEO_DIR: Path   = BASE_DIR / "query_videos"
INDEX_SAVE_PATH: Path   = BASE_DIR / "artifacts" / "faiss.index"
PATHS_SAVE_PATH: Path   = BASE_DIR / "artifacts" / "video_paths.npy"
LOG_DIR: Path           = BASE_DIR / "logs"

# Ensure required directories exist at import time
for _dir in (VIDEO_DB_DIR, QUERY_IMAGE_DIR, QUERY_VIDEO_DIR,
             INDEX_SAVE_PATH.parent, LOG_DIR):
    _dir.mkdir(parents=True, exist_ok=True)

# ───────────────────────── CLIP Model ────────────────────────
CLIP_MODEL_NAME: str    = "ViT-B-32"
CLIP_PRETRAINED: str    = "openai"
EMBEDDING_DIM: int      = 512          # ViT-B-32 output dimension

# ─────────────────────── Video Processing ────────────────────
FRAME_SAMPLES: int      = 15           # frames sampled per video
SUPPORTED_VIDEO_EXTS: tuple[str, ...] = (".mp4", ".avi", ".mov", ".mkv", ".webm")

# ───────────────────────── Retrieval ─────────────────────────
TOP_K: int              = 1            # number of results to return

# ─────────────────────────── Device ──────────────────────────
DEVICE: str             = "cuda" if torch.cuda.is_available() else "cpu"

# ───────────────────────── Logging ───────────────────────────
LOG_LEVEL: str          = "INFO"
LOG_FILE: Path          = LOG_DIR / "retrieval.log"
