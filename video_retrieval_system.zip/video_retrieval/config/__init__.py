"""Configuration package."""
from .settings import *   # re-export everything for convenience
