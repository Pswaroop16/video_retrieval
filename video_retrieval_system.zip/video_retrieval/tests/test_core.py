"""
tests/test_core.py
------------------
Unit tests for the three core modules:
  - VideoProcessor
  - CLIPEmbedder
  - IndexManager

Tests use mock/stub objects to avoid needing real video files or a GPU,
keeping the test suite fast and deterministic.
"""

from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
from PIL import Image


# ─────────────────────────── VideoProcessor ─────────────────────────────────

class TestVideoProcessor(unittest.TestCase):
    """Unit tests for VideoProcessor.extract_frames."""

    def _make_processor(self):
        from core.video_processor import VideoProcessor
        return VideoProcessor(num_samples=5)

    def test_extract_frames_missing_file_raises(self):
        proc = self._make_processor()
        with self.assertRaises(FileNotFoundError):
            proc.extract_frames("/nonexistent/video.mp4")

    def test_extract_frames_returns_list(self):
        """Verify that a mocked VideoCapture returns PIL Images."""
        proc = self._make_processor()

        mock_frame = np.zeros((100, 100, 3), dtype=np.uint8)
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.return_value = 30  # total frames
        mock_cap.read.return_value = (True, mock_frame)

        with patch("cv2.VideoCapture", return_value=mock_cap), \
             patch("core.video_processor.validate_file",
                   return_value=Path("/fake/video.mp4")):
            frames = proc.extract_frames("/fake/video.mp4")

        self.assertIsInstance(frames, list)
        self.assertGreater(len(frames), 0)
        self.assertIsInstance(frames[0], Image.Image)

    def test_extract_frames_unopenable_returns_empty(self):
        proc = self._make_processor()
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = False

        with patch("cv2.VideoCapture", return_value=mock_cap), \
             patch("core.video_processor.validate_file",
                   return_value=Path("/fake/video.mp4")):
            frames = proc.extract_frames("/fake/video.mp4")

        self.assertEqual(frames, [])


# ──────────────────────────── CLIPEmbedder ───────────────────────────────────

class TestCLIPEmbedder(unittest.TestCase):
    """Unit tests for CLIPEmbedder (model loading is mocked)."""

    def _make_embedder(self):
        """Create an embedder with all torch/openclip calls mocked out."""
        import torch
        from core.embedder import CLIPEmbedder

        mock_model = MagicMock()
        fake_features = torch.zeros(1, 512)
        # norm of zeros is 0; set to ones to avoid NaN
        fake_features[:] = 1.0
        mock_model.encode_image.return_value = fake_features

        mock_preprocess = MagicMock(
            side_effect=lambda img: torch.zeros(3, 224, 224)
        )

        with patch("open_clip.create_model_and_transforms",
                   return_value=(mock_model, None, mock_preprocess)):
            embedder = CLIPEmbedder(device="cpu")
        return embedder

    def test_encode_images_shape(self):
        embedder = self._make_embedder()
        images = [Image.new("RGB", (64, 64)) for _ in range(3)]

        import torch
        with patch.object(
            embedder._model, "encode_image",
            return_value=torch.ones(3, 512),
        ):
            result = embedder.encode_images(images)

        self.assertEqual(result.shape[1], 512)
        self.assertEqual(result.dtype, np.float32)

    def test_encode_images_empty_raises(self):
        embedder = self._make_embedder()
        with self.assertRaises(ValueError):
            embedder.encode_images([])

    def test_aggregate_video_embedding_shape(self):
        embedder = self._make_embedder()
        images = [Image.new("RGB", (64, 64)) for _ in range(5)]

        import torch
        with patch.object(
            embedder._model, "encode_image",
            return_value=torch.ones(5, 512),
        ):
            result = embedder.aggregate_video_embedding(images)

        self.assertEqual(result.shape, (1, 512))


# ───────────────────────────── IndexManager ──────────────────────────────────

class TestIndexManager(unittest.TestCase):
    """Unit tests for IndexManager: build, search, persist, load."""

    def _make_manager(self):
        from core.index_manager import IndexManager
        return IndexManager(embedding_dim=4, top_k=1)

    def _random_embeddings(self, n: int = 5) -> np.ndarray:
        vecs = np.random.rand(n, 4).astype("float32")
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        return vecs / norms

    def test_build_sets_is_built(self):
        mgr = self._make_manager()
        embs = self._random_embeddings(3)
        paths = [Path(f"/fake/vid{i}.mp4") for i in range(3)]
        mgr.build(embs, paths)
        self.assertTrue(mgr.is_built)

    def test_build_empty_raises(self):
        mgr = self._make_manager()
        with self.assertRaises(ValueError):
            mgr.build(np.empty((0, 4), dtype="float32"), [])

    def test_build_mismatch_raises(self):
        mgr = self._make_manager()
        with self.assertRaises(ValueError):
            mgr.build(self._random_embeddings(3), [Path("/fake/a.mp4")])

    def test_search_returns_result(self):
        from core.index_manager import RetrievalResult
        mgr = self._make_manager()
        embs = self._random_embeddings(3)
        paths = [Path(f"/fake/vid{i}.mp4") for i in range(3)]
        mgr.build(embs, paths)

        query = embs[[0]]  # use first video as its own query
        results = mgr.search(query)

        self.assertEqual(len(results), 1)
        self.assertIsInstance(results[0], RetrievalResult)
        self.assertEqual(results[0].rank, 1)

    def test_search_before_build_raises(self):
        mgr = self._make_manager()
        with self.assertRaises(RuntimeError):
            mgr.search(np.zeros((1, 4), dtype="float32"))

    def test_search_wrong_shape_raises(self):
        mgr = self._make_manager()
        embs = self._random_embeddings(2)
        mgr.build(embs, [Path("/a.mp4"), Path("/b.mp4")])
        with self.assertRaises(ValueError):
            mgr.search(np.zeros((4,), dtype="float32"))

    def test_save_and_load(self):
        import tempfile
        from core.index_manager import IndexManager

        mgr = IndexManager(embedding_dim=4, top_k=1)
        embs = self._random_embeddings(3)
        paths = [Path(f"/fake/vid{i}.mp4") for i in range(3)]
        mgr.build(embs, paths)

        with tempfile.TemporaryDirectory() as tmpdir:
            idx_path = Path(tmpdir) / "test.index"
            pth_path = Path(tmpdir) / "test.npy"
            mgr.save(idx_path, pth_path)

            mgr2 = IndexManager(embedding_dim=4, top_k=1)
            mgr2.load(idx_path, pth_path)
            self.assertTrue(mgr2.is_built)
            self.assertEqual(len(mgr2._video_paths), 3)


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    unittest.main()
